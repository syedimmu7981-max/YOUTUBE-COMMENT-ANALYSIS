import pandas as pd
from textblob import TextBlob
import matplotlib.pyplot as plt

data = pd.read_csv("comments.csv")

def get_sentiment(comment):
    score = TextBlob(str(comment)).sentiment.polarity
    if score > 0:
        return "Positive"
    elif score < 0:
        return "Negative"
    return "Neutral"

data["Sentiment"] = data["comment"].apply(get_sentiment)

print(data)

sentiment_count = data["Sentiment"].value_counts()
sentiment_count.plot(kind="bar")

plt.title("YouTube Comment Sentiment Analysis")
plt.xlabel("Sentiment")
plt.ylabel("Number of Comments")
plt.savefig("sentiment_chart.png")
plt.show()

print("Analysis Completed Successfully")
